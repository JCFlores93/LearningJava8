package org.formacion;

import java.util.List;
import java.util.function.Predicate;
import java.util.ArrayList;

public class Validador <T> {

	// falta indicar el tipo de List
	List validadores = new ArrayList<>();
	
	public boolean valida(Object valor) { // cambiar Object por el tipo adecuado
	   // true si pasa todos los validadores, falso si no
		return true;
	}
	
	// falta un metodo add que admite nuevas validaciones
}
