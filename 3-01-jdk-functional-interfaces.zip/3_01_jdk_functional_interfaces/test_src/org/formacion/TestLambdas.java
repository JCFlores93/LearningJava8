package org.formacion;

import static org.junit.Assert.*;

import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.IntUnaryOperator;
import java.util.function.LongBinaryOperator;
import java.util.function.Predicate;

import org.junit.Test;

public class TestLambdas {

	
	@Test
	public void test_function() {
		
		IntUnaryOperator cuadrado = null;
		
		assertEquals(0, cuadrado.applyAsInt(0));
		assertEquals(1, cuadrado.applyAsInt(1));
		assertEquals(4, cuadrado.applyAsInt(2));
		assertEquals(9, cuadrado.applyAsInt(3));
	}
	
	@Test
	public void test_funcion_2() {
		
		LongBinaryOperator menor = null;
		
		assertEquals(-2, menor.applyAsLong(-2, 3));
		assertEquals(5, menor.applyAsLong(10, 5));
	}
	
	/**
	 * En los siguientes ejercicios debereis implementar tanto la declaracion de la 
	 * interface funcional como la lambda expression a assignar.
	 * Se utiliza el termino generico funcion, pero la opcion a usar puede ser cualquier tipo de 
	 * interface funcional del JDK
	 */
	@Test
	public void test_extras() {
		
		// Una funcion que indique si el segundo apellido de una persona es null
		
		// Una funcion que nos diga si dos personas son parientes: para nosotros parientes
		// son personas con el mismo primer apellido
		
		// Una funcion que "enmascare" los datos de una persona: debe permutar los valores de sus
		// y nombre
	}
	
	
	@Test
	public void test_validadores() {
		
		/**
		 * Modificad la clase validador:
		 *  - a�adir un tipo generico que indique el tipo de elemento que valida
		 *  - a�adir un metodo add que admita un predicado para validar el objeto
		 *  - a�adir un metodo valida que devuelva true si el objeto que se pasa como parametro 
		 *      cumple todas las validaciones
		 */
		//Validador<Persona> validador = new Validador<Persona>();
		
		//validador.add(/* pasar un predicado que mire si el primer apellido es null */ );
		
		//assertTrue(validador.valida(new Persona("nombre","ape1","ape2")));
		//assertFalse(validador.valida(new Persona("nombre",null,"ape2")));
	}
	
	
}
